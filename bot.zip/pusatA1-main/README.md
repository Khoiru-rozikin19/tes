````
HAPPY NEWYEAR 2025
````
### Wajib Makek Domain Sendiri

<p align="center">
<img src="https://readme-typing-svg.herokuapp.com?color=%2336BCF7&center=true&vCenter=true&lines=H+A+P+P+Y+++N+E+W+++Y+Y+E+A+R++2025" />
</p>

````
apt install -y && apt update -y && apt upgrade -y && wget -q https://raw.githubusercontent.com/Arya-Blitar22/pusatA1/main/setup.sh && chmod +x setup.sh && ./setup.sh
````

![logo](https://raw.githubusercontent.com/Arya-Blitar22/pusatA1/main/sct.png)


SCRIPT HAPROXY GRATIS TIDAK PERLU IJIN IP SAYANK.. DEBIAN 10 / UBUNTU 20.04 LANGSUNG INSTALL AJA!!!
REKOMONDASI MAKEK DOMAIN SENDIRI

Bisa Donasi Seikhlasnya 🤣

### Youtube Tutorial Terbaru
https://youtu.be/SATdvbXFmfo


Sedia AkunSsh Premium 10k isp indo & Sgdo
### BISA HUBUNGI
<a href="https://t.me/AryaBlitar" target=”_blank”><img src="https://img.shields.io/static/v1?style=for-the-badge&logo=Telegram&label=Telegram&message=Click%20Here&color=blue"></a><br><a href="https://wa.me/6281931615811" target=”_blank”><img src="https://img.shields.io/static/v1?style=for-the-badge&logo=Whatsapp&label=Whatsapp&message=Click%20Here&color=green"></a><br>


