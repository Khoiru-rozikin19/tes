#!/bin/bash
# ==========================================
# Color
RED='\033[0;31m'
NC='\033[0m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
LIGHT='\033[0;37m'
NC='\033[0;37m'
# ==========================================
clear
echo -e ""
echo -e " ${GREEN} Starting Restart All Service ${NC}"
sleep 2
systemctl restart ws
systemctl restart haproxy
systemctl restart xray
systemctl restart openvpn
/etc/init.d/ssh restart
systemctl restart ssh
/etc/init.d/dropbear restart
/etc/init.d/openvpn restart
/etc/init.d/nginx restart
systemctl disable udp-mini-1
systemctl stop udp-mini-1
systemctl enable udp-mini-1
systemctl start udp-mini-1
systemctl disable udp-mini-2
systemctl stop udp-mini-2
systemctl enable udp-mini-2
systemctl start udp-mini-2
systemctl disable udp-mini-3
systemctl stop udp-mini-3
systemctl enable udp-mini-3
systemctl start udp-mini-3
echo ""
echo -e " ${GREEN} Back to menu in 2 sec ${NC}"
sleep 2
menu restart.temp1.sh 